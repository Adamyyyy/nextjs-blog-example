declare namespace NodeJS {
  interface Process {
    browser: boolean
  }
}
