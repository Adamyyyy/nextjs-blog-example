declare module "*.css" {
  const content: any
  export default content
}
